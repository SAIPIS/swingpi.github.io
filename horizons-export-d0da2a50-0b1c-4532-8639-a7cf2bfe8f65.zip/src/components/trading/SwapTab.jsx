import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowUpDown, Lock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet } from '@/contexts/WalletContext';

const SwapTab = ({ swapForm, setSwapForm, handleSwap, balances }) => {
  const { user } = useAuth();
  const { canTrade } = useWallet();

  if (!canTrade()) {
    return (
      <Card className="glass-effect border-red-500/30">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center">
            <Lock className="w-5 h-5 mr-2" />
            Swap Locked
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <Lock className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">Swap Feature Locked</h3>
          <p className="text-gray-400 mb-4">
            Swap is only available for Phase 3+ users with completed KYC verification
          </p>
          <div className="space-y-2 text-sm">
            <p className="text-gray-400">Current Phase: {user?.phase || 1} (Need: Phase 3+)</p>
            <p className="text-gray-400">KYC Status: {user?.kycStatus || 'Pending'} (Need: Verified)</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-effect border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <ArrowUpDown className="w-5 h-5 mr-2 text-purple-400" />
          Instant Swap
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSwap} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-gray-400 text-sm">From</label>
              <select
                value={swapForm.fromCoin}
                onChange={(e) => setSwapForm({ ...swapForm, fromCoin: e.target.value })}
                className="w-full mt-1 p-3 bg-slate-800 border border-purple-500/30 rounded-lg text-white"
              >
                {Object.keys(balances).map(coin => (
                  <option key={coin} value={coin}>
                    {coin} ({balances[coin].toFixed(2)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-gray-400 text-sm">To</label>
              <select
                value={swapForm.toCoin}
                onChange={(e) => setSwapForm({ ...swapForm, toCoin: e.target.value })}
                className="w-full mt-1 p-3 bg-slate-800 border border-purple-500/30 rounded-lg text-white"
              >
                {Object.keys(balances).filter(coin => coin !== swapForm.fromCoin).map(coin => (
                  <option key={coin} value={coin}>
                    {coin}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="text-gray-400 text-sm">Amount</label>
            <Input
              type="number"
              step="0.01"
              placeholder="0.00"
              value={swapForm.amount}
              onChange={(e) => setSwapForm({ ...swapForm, amount: e.target.value })}
              className="mt-1 bg-slate-800 border-purple-500/30 text-white"
            />
          </div>

          <div className="bg-slate-800/50 p-4 rounded-lg">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Exchange Rate</span>
              <span className="text-white">1 {swapForm.fromCoin} = 8.33 {swapForm.toCoin}</span>
            </div>
            <div className="flex justify-between text-sm mt-2">
              <span className="text-gray-400">Trading Fee (0.3%)</span>
              <span className="text-white">{swapForm.amount ? (parseFloat(swapForm.amount) * 0.003).toFixed(4) : '0.0000'} {swapForm.fromCoin}</span>
            </div>
          </div>

          <Button
            type="submit"
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
          >
            <ArrowUpDown className="w-4 h-4 mr-2" />
            Swap Now
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default SwapTab;