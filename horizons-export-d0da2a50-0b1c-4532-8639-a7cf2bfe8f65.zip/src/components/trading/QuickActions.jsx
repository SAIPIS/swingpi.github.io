import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp, TrendingDown, ArrowUpDown, Users } from 'lucide-react';

const QuickActions = ({ handleDeposit, handleWithdraw, handleP2PTrade, handleSwapClick }) => {
  const actions = [
    { label: 'Deposit', icon: TrendingUp, color: 'green', handler: handleDeposit },
    { label: 'Withdraw', icon: TrendingDown, color: 'red', handler: handleWithdraw },
    { label: 'Swap', icon: ArrowUpDown, color: 'purple', handler: handleSwapClick },
    { label: 'P2P Trade', icon: Users, color: 'blue', handler: handleP2PTrade },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {actions.map((action) => {
        const Icon = action.icon;
        return (
          <motion.div key={action.label} whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Card
              className={`glass-effect border-${action.color}-500/30 cursor-pointer hover:border-${action.color}-400/50 transition-all`}
              onClick={action.handler}
            >
              <CardContent className="p-4 text-center">
                <Icon className={`w-8 h-8 text-${action.color}-400 mx-auto mb-2`} />
                <p className="text-white font-semibold">{action.label}</p>
              </CardContent>
            </Card>
          </motion.div>
        );
      })}
    </div>
  );
};

export default QuickActions;