import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, BrainCircuit } from 'lucide-react';

const AITradingInsights = () => {
  return (
    <Card className="glass-effect border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <BrainCircuit className="w-5 h-5 mr-2 text-yellow-400" />
          AI Trading Insights
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Market Sentiment</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-400">SPI Coin</span>
                <span className="text-green-400 font-semibold">Bullish 📈</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">PI Network</span>
                <span className="text-yellow-400 font-semibold">Neutral ➡️</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">USDT</span>
                <span className="text-blue-400 font-semibold">Stable 🔒</span>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">AI Recommendations</h3>
            <div className="space-y-3">
              <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
                <p className="text-green-400 text-sm font-semibold">💡 Consider accumulating SPI during dips</p>
              </div>
              <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
                <p className="text-blue-400 text-sm font-semibold">📊 Diversify with USDT for stability</p>
              </div>
              <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded-lg">
                <p className="text-purple-400 text-sm font-semibold">🎯 Set stop-loss at 10% below entry</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">AI Price Prediction (SPI)</h3>
            <div className="space-y-3">
              <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-purple-400 font-semibold">1 Month</span>
                  <span className="text-white font-bold">$0.25 📈</span>
                </div>
              </div>
              <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-purple-400 font-semibold">6 Months</span>
                  <span className="text-white font-bold">$0.78 🚀</span>
                </div>
              </div>
              <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded-lg">
                <div className="flex justify-between items-center">
                  <span className="text-purple-400 font-semibold">1 Year</span>
                  <span className="text-white font-bold">$1.50 🔥</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AITradingInsights;