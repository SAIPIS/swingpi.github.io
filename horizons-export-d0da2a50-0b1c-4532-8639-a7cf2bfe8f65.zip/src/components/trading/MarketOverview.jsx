import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart3 } from 'lucide-react';

const MarketOverview = () => {
  const tradingPairs = [
    { pair: 'SPI/USDT', price: 0.12, change: 5.2, volume: '1.2M' },
    { pair: 'PI/USDT', price: 0.08, change: -2.1, volume: '890K' },
    { pair: 'PI/SPI', price: 0.67, change: 3.4, volume: '420K' }
  ];

  return (
    <Card className="glass-effect border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <BarChart3 className="w-5 h-5 mr-2 text-green-400" />
          Market Overview
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {tradingPairs.map((pair) => (
            <div key={pair.pair} className="p-4 rounded-lg bg-white/5 hover:bg-white/10 transition-all cursor-pointer">
              <div className="flex justify-between items-start mb-2">
                <span className="text-white font-semibold">{pair.pair}</span>
                <span className={`text-sm ${pair.change > 0 ? 'text-green-400' : 'text-red-400'}`}>
                  {pair.change > 0 ? '+' : ''}{pair.change}%
                </span>
              </div>
              <p className="text-2xl font-bold text-white mb-1">${pair.price}</p>
              <p className="text-gray-400 text-sm">Vol: {pair.volume}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default MarketOverview;