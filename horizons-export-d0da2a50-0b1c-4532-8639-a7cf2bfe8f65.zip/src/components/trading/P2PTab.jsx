import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Lock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet } from '@/contexts/WalletContext';

const P2PTab = ({ handleP2PTrade }) => {
  const { user } = useAuth();
  const { canTrade } = useWallet();

  if (!canTrade()) {
    return (
      <Card className="glass-effect border-red-500/30">
        <CardHeader>
          <CardTitle className="text-red-400 flex items-center">
            <Lock className="w-5 h-5 mr-2" />
            P2P Trading Locked
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <Lock className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">P2P Trading Locked</h3>
          <p className="text-gray-400 mb-4">
            P2P Trading is only available for Phase 3+ users with completed KYC verification
          </p>
          <div className="space-y-2 text-sm">
            <p className="text-gray-400">Current Phase: {user?.phase || 1} (Need: Phase 3+)</p>
            <p className="text-gray-400">KYC Status: {user?.kycStatus || 'Pending'} (Need: Verified)</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-effect border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Users className="w-5 h-5 mr-2 text-blue-400" />
          Peer-to-Peer Trading
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center py-8">
          <Users className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">P2P Trading Available</h3>
          <p className="text-gray-400 mb-4">Trade directly with other users with 0.3% fee</p>
          <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
            <div className="p-4 bg-slate-800/50 rounded-lg">
              <p className="text-white font-semibold">Buy Orders</p>
              <p className="text-gray-400 text-sm">SPI/USDT</p>
              <p className="text-gray-400 text-sm">PI/USDT</p>
            </div>
            <div className="p-4 bg-slate-800/50 rounded-lg">
              <p className="text-white font-semibold">Sell Orders</p>
              <p className="text-gray-400 text-sm">SPI/USDT</p>
              <p className="text-gray-400 text-sm">PI/SPI</p>
            </div>
          </div>
          <Button
            onClick={handleP2PTrade}
            className="mt-6 bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600"
          >
            Start P2P Trading
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default P2PTab;