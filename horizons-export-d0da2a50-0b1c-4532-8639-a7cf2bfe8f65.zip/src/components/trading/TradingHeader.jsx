import React from 'react';

const TradingHeader = () => {
  return (
    <div className="text-center">
      <h1 className="text-3xl font-bold gradient-text mb-2">SPI Trading Platform</h1>
      <p className="text-gray-400">AI-powered trading with real-time market insights</p>
    </div>
  );
};

export default TradingHeader;