import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BarChart3, Clock, Hash, Zap } from 'lucide-react';
import { useWallet } from '@/contexts/WalletContext';
import { useToast } from '@/components/ui/use-toast';

const ExplorerTab = () => {
  const { getBlockchainStats } = useWallet();
  const { toast } = useToast();
  const stats = getBlockchainStats();

  return (
    <Card className="glass-effect border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <BarChart3 className="w-5 h-5 mr-2 text-orange-400" />
          SPI Blockchain Explorer
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="text-center">
            <h3 className="text-xl font-semibold text-white mb-2">SPI Network Statistics</h3>
            <p className="text-gray-400 mb-4">Real-time blockchain data and network metrics</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-slate-800/50 rounded-lg">
              <div className="flex items-center mb-2">
                <Hash className="w-5 h-5 text-purple-400 mr-2" />
                <p className="text-white font-semibold">Total Blocks</p>
              </div>
              <p className="text-2xl font-bold text-purple-400">{stats.totalBlocks.toLocaleString()}</p>
              <p className="text-gray-400 text-sm">Confirmed blocks</p>
            </div>

            <div className="p-4 bg-slate-800/50 rounded-lg">
              <div className="flex items-center mb-2">
                <BarChart3 className="w-5 h-5 text-green-400 mr-2" />
                <p className="text-white font-semibold">Transactions</p>
              </div>
              <p className="text-2xl font-bold text-green-400">{stats.totalTransactions.toLocaleString()}</p>
              <p className="text-gray-400 text-sm">Total processed</p>
            </div>

            <div className="p-4 bg-slate-800/50 rounded-lg">
              <div className="flex items-center mb-2">
                <Zap className="w-5 h-5 text-blue-400 mr-2" />
                <p className="text-white font-semibold">Active Wallets</p>
              </div>
              <p className="text-2xl font-bold text-blue-400">{stats.activeWallets.toLocaleString()}</p>
              <p className="text-gray-400 text-sm">Network participants</p>
            </div>

            <div className="p-4 bg-slate-800/50 rounded-lg">
              <div className="flex items-center mb-2">
                <Clock className="w-5 h-5 text-yellow-400 mr-2" />
                <p className="text-white font-semibold">Network Hashrate</p>
              </div>
              <p className="text-2xl font-bold text-yellow-400">{stats.networkHashrate}</p>
              <p className="text-gray-400 text-sm">Mining power</p>
            </div>
          </div>

          <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
            <h4 className="text-blue-400 font-semibold mb-2">Latest Block Information</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Block Height:</span>
                <span className="text-white">{stats.totalBlocks}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Timestamp:</span>
                <span className="text-white">{new Date(stats.lastBlock).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Difficulty:</span>
                <span className="text-white">{stats.difficulty.toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="text-center">
            <Button
              onClick={() => toast({ title: "🚧 Advanced explorer features aren't implemented yet—but don't worry! You can request them in your next prompt! 🚀" })}
              className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              View Advanced Analytics
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ExplorerTab;