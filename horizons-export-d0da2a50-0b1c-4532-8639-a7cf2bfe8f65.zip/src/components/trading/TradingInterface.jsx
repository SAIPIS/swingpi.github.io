import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import SwapTab from '@/components/trading/SwapTab';
import P2PTab from '@/components/trading/P2PTab';
import ExplorerTab from '@/components/trading/ExplorerTab';

const TradingInterface = ({ swapForm, setSwapForm, handleSwap, balances, handleP2PTrade, activeTab, setActiveTab }) => {
  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="grid w-full grid-cols-3 bg-slate-800/50">
        <TabsTrigger value="swap" className="text-white">Swap</TabsTrigger>
        <TabsTrigger value="p2p" className="text-white">P2P Trade</TabsTrigger>
        <TabsTrigger value="explorer" className="text-white">Explorer</TabsTrigger>
      </TabsList>

      <TabsContent value="swap">
        <SwapTab 
          swapForm={swapForm}
          setSwapForm={setSwapForm}
          handleSwap={handleSwap}
          balances={balances}
        />
      </TabsContent>

      <TabsContent value="p2p">
        <P2PTab handleP2PTrade={handleP2PTrade} />
      </TabsContent>

      <TabsContent value="explorer">
        <ExplorerTab />
      </TabsContent>
    </Tabs>
  );
};

export default TradingInterface;