import React from 'react';
import { motion } from 'framer-motion';
import { Home, Shovel as Pickaxe, Wallet, TrendingUp, User, LogOut } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const Navigation = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { logout } = useAuth();

  const navItems = [
    { icon: Home, label: 'Dashboard', path: '/' },
    { icon: Pickaxe, label: 'Mining', path: '/mining' },
    { icon: Wallet, label: 'Wallet', path: '/wallet' },
    { icon: TrendingUp, label: 'Trading', path: '/trading' },
    { icon: User, label: 'Profile', path: '/profile' },
  ];

  const handleLogout = () => {
    logout();
    navigate('/auth');
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 md:top-0 md:left-0 md:bottom-auto md:w-20 md:h-full">
      <div className="glass-effect border-t md:border-t-0 md:border-r border-white/10">
        <div className="flex md:flex-col justify-around md:justify-start md:py-8 py-2 px-4 md:px-0 md:space-y-6">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            
            return (
              <motion.button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`relative flex flex-col md:flex-row items-center justify-center p-3 rounded-xl transition-all duration-300 ${
                  isActive 
                    ? 'text-purple-400 bg-purple-500/20' 
                    : 'text-gray-400 hover:text-white hover:bg-white/10'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Icon className="w-6 h-6 mb-1 md:mb-0" />
                <span className="text-xs md:hidden">{item.label}</span>
                {isActive && (
                  <motion.div
                    className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl"
                    layoutId="activeTab"
                    initial={false}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  />
                )}
              </motion.button>
            );
          })}
          
          <motion.button
            onClick={handleLogout}
            className="flex flex-col md:flex-row items-center justify-center p-3 rounded-xl text-red-400 hover:text-red-300 hover:bg-red-500/20 transition-all duration-300 md:mt-auto"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <LogOut className="w-6 h-6 mb-1 md:mb-0" />
            <span className="text-xs md:hidden">Logout</span>
          </motion.button>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;