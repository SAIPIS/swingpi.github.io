import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Settings, Trash2, LogOut, Download, Upload } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';

const AdvancedSettings = ({ settings, setSettings }) => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSignOut = () => {
    logout();
    navigate('/auth');
    toast({
      title: "Signed Out Successfully",
      description: "You have been logged out of your account.",
    });
  };

  const handleDeleteAccount = () => {
    toast({
      title: "Account Deletion",
      description: "This action requires additional confirmation. Please contact support.",
      variant: "destructive"
    });
  };

  const handleExportData = () => {
    toast({
      title: "🚧 Data export isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const handleImportData = () => {
    toast({
      title: "🚧 Data import isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  return (
    <Card className="glass-effect border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Settings className="w-5 h-5 mr-2 text-blue-400" />
          Advanced Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white font-medium">Auto-backup</p>
              <p className="text-gray-400 text-sm">Automatically backup wallet data</p>
            </div>
            <Switch
              checked={settings.autoBackup}
              onCheckedChange={(checked) => setSettings({ ...settings, autoBackup: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-white font-medium">Transaction Notifications</p>
              <p className="text-gray-400 text-sm">Get notified for all transactions</p>
            </div>
            <Switch
              checked={settings.transactionNotifications}
              onCheckedChange={(checked) => setSettings({ ...settings, transactionNotifications: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-white font-medium">Privacy Mode</p>
              <p className="text-gray-400 text-sm">Hide balances by default</p>
            </div>
            <Switch
              checked={settings.privacyMode}
              onCheckedChange={(checked) => setSettings({ ...settings, privacyMode: checked })}
            />
          </div>
        </div>

        <div className="border-t border-gray-600 pt-6">
          <h3 className="text-white font-semibold mb-4">Data Management</h3>
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              onClick={handleExportData}
              className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
            >
              <Download className="w-4 h-4 mr-2" />
              Export Data
            </Button>
            <Button
              variant="outline"
              onClick={handleImportData}
              className="border-green-500/30 text-green-400 hover:bg-green-500/10"
            >
              <Upload className="w-4 h-4 mr-2" />
              Import Data
            </Button>
          </div>
        </div>

        <div className="border-t border-gray-600 pt-6">
          <h3 className="text-white font-semibold mb-4">Account Actions</h3>
          <div className="space-y-3">
            <Button
              onClick={handleSignOut}
              variant="outline"
              className="w-full border-orange-500/30 text-orange-400 hover:bg-orange-500/10"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
            <Button
              onClick={handleDeleteAccount}
              variant="outline"
              className="w-full border-red-500/30 text-red-400 hover:bg-red-500/10"
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Account
            </Button>
          </div>
        </div>

        <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
          <p className="text-yellow-400 text-sm font-semibold">⚠️ Important Notice</p>
          <p className="text-gray-300 text-xs mt-1">
            Account deletion is permanent and cannot be undone. All your SPI coins and data will be lost.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default AdvancedSettings;