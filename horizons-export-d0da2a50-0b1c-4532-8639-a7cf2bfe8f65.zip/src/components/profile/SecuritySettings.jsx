import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Settings, Bell, Smartphone, Eye, Shield, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const SecuritySettings = ({ settings, setSettings, user }) => {
  const { setupBiometric } = useAuth();
  const { toast } = useToast();
  const [isSettingUpBiometric, setIsSettingUpBiometric] = useState(false);

  const handleBiometricSetup = async () => {
    setIsSettingUpBiometric(true);
    
    try {
      await setupBiometric();
      toast({
        title: "Biometric Setup Complete! 👆",
        description: "You can now use fingerprint or face ID to login.",
      });
      setSettings({ ...settings, biometric: true });
    } catch (error) {
      toast({
        title: "Biometric Setup Failed",
        description: error.message || "Please try again or check your device settings.",
        variant: "destructive"
      });
    } finally {
      setIsSettingUpBiometric(false);
    }
  };

  return (
    <Card className="glass-effect border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Settings className="w-5 h-5 mr-2 text-blue-400" />
          Security & Settings
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Bell className="w-5 h-5 text-yellow-400" />
              <div>
                <p className="text-white font-medium">Push Notifications</p>
                <p className="text-gray-400 text-sm">Receive mining and trading alerts</p>
              </div>
            </div>
            <Switch
              checked={settings.notifications}
              onCheckedChange={(checked) => setSettings({ ...settings, notifications: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Smartphone className="w-5 h-5 text-green-400" />
              <div>
                <p className="text-white font-medium">Biometric Authentication</p>
                <p className="text-gray-400 text-sm">Use fingerprint or face ID to login</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                checked={settings.biometric || user.biometricSetup}
                onCheckedChange={(checked) => setSettings({ ...settings, biometric: checked })}
                disabled={!user.biometricSetup}
              />
              <Button
                variant="ghost"
                size="sm"
                onClick={handleBiometricSetup}
                disabled={isSettingUpBiometric || user.biometricSetup}
                className="text-green-400 hover:text-green-300 disabled:opacity-50"
              >
                {isSettingUpBiometric ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : user.biometricSetup ? (
                  'Enabled'
                ) : (
                  'Setup'
                )}
              </Button>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Eye className="w-5 h-5 text-purple-400" />
              <div>
                <p className="text-white font-medium">Dark Mode</p>
                <p className="text-gray-400 text-sm">Use dark theme interface</p>
              </div>
            </div>
            <Switch
              checked={settings.darkMode}
              onCheckedChange={(checked) => setSettings({ ...settings, darkMode: checked })}
            />
          </div>

          {user.phase >= 3 && (
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Shield className="w-5 h-5 text-red-400" />
                <div>
                  <p className="text-white font-medium">Auto KYC Lock</p>
                  <p className="text-gray-400 text-sm">Lock coins until KYC verification</p>
                </div>
              </div>
              <Switch
                checked={settings.autoKyc}
                onCheckedChange={(checked) => setSettings({ ...settings, autoKyc: checked })}
                disabled={user.kycStatus !== 'verified'}
              />
            </div>
          )}

          {user.biometricSetup && (
            <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
              <p className="text-green-400 text-sm font-semibold">
                ✅ Biometric authentication is enabled and ready to use!
              </p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default SecuritySettings;