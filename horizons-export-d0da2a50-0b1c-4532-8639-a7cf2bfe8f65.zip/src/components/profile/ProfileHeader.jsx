import React from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

const ProfileHeader = ({ user, isEditing, setIsEditing }) => {
  return (
    <div className="flex items-center space-x-6 mb-6">
      <Avatar className="w-20 h-20">
        <AvatarImage src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user.email}`} />
        <AvatarFallback className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xl">
          {user.name.charAt(0).toUpperCase()}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <h2 className="text-2xl font-bold text-white">{user.name}</h2>
        <p className="text-gray-400">{user.email}</p>
        <p className="text-sm text-purple-400 mt-1">
          Member since {new Date(user.joinDate).toLocaleDateString()}
        </p>
      </div>
      <Button
        onClick={() => setIsEditing(!isEditing)}
        variant="outline"
        className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10"
      >
        {isEditing ? 'Cancel' : 'Edit'}
      </Button>
    </div>
  );
};

export default ProfileHeader;