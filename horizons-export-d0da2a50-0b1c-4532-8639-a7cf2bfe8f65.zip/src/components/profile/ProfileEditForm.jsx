import React from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

const ProfileEditForm = ({ profileData, setProfileData, handleSaveProfile }) => {
  return (
    <div className="space-y-4">
      <div>
        <label className="text-gray-400 text-sm">Full Name</label>
        <Input
          value={profileData.name}
          onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
          className="mt-1 bg-slate-800 border-purple-500/30 text-white"
        />
      </div>
      <div>
        <label className="text-gray-400 text-sm">Email Address</label>
        <Input
          value={profileData.email}
          onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
          className="mt-1 bg-slate-800 border-purple-500/30 text-white"
        />
      </div>
      <Button
        onClick={handleSaveProfile}
        className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
      >
        Save Changes
      </Button>
    </div>
  );
};

export default ProfileEditForm;