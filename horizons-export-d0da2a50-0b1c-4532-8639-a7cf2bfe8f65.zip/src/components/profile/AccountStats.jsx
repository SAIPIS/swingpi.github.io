import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar } from 'lucide-react';

const AccountStats = ({ user, miningData }) => {
  return (
    <Card className="glass-effect border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Calendar className="w-5 h-5 mr-2 text-orange-400" />
          Account Statistics
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center p-4 bg-slate-800/50 rounded-lg">
            <p className="text-2xl font-bold text-purple-400">{user?.created_at ? Math.floor((new Date() - new Date(user.created_at)) / (1000 * 60 * 60 * 24)) : 0}</p>
            <p className="text-gray-400 text-sm">Days Active</p>
          </div>
          <div className="text-center p-4 bg-slate-800/50 rounded-lg">
            <p className="text-2xl font-bold text-green-400">{(miningData?.total_mined || 0).toFixed(0)}</p>
            <p className="text-gray-400 text-sm">SPI Mined</p>
          </div>
          <div className="text-center p-4 bg-slate-800/50 rounded-lg">
            <p className="text-2xl font-bold text-orange-400">{miningData?.check_in_streak || 0}</p>
            <p className="text-gray-400 text-sm">Check-in Streak</p>
          </div>
          <div className="text-center p-4 bg-slate-800/50 rounded-lg">
            <p className="text-2xl font-bold text-blue-400">{user?.phase || 1}</p>
            <p className="text-gray-400 text-sm">Current Phase</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default AccountStats;