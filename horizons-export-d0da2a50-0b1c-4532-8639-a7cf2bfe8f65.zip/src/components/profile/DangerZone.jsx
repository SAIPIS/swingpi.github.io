import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, Download } from 'lucide-react';
import { useWallet } from '@/contexts/WalletContext';
import { useToast } from '@/components/ui/use-toast';

const DangerZone = () => {
  const { createWalletBackup, miningData } = useWallet();
  const { toast } = useToast();

  const handleBackupWallet = () => {
    try {
      createWalletBackup();
      toast({
        title: "Wallet Backup Created! 💾",
        description: "Your wallet backup has been downloaded successfully.",
      });
    } catch (error) {
      toast({
        title: "Backup Failed",
        description: "Failed to create wallet backup. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <Card className="glass-effect border-red-500/30">
      <CardHeader>
        <CardTitle className="text-red-400 flex items-center">
          <Shield className="w-5 h-5 mr-2" />
          Wallet Security
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white font-medium">Backup Wallet</p>
              <p className="text-gray-400 text-sm">Download encrypted backup of your wallet data</p>
            </div>
            <Button
              variant="outline"
              className="border-green-500/30 text-green-400 hover:bg-green-500/10"
              onClick={handleBackupWallet}
            >
              <Download className="w-4 h-4 mr-2" />
              {miningData.backupCreated ? 'Update Backup' : 'Create Backup'}
            </Button>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white font-medium">Reset Account</p>
              <p className="text-gray-400 text-sm">This will permanently delete all your data</p>
            </div>
            <Button
              variant="outline"
              className="border-red-500/30 text-red-400 hover:bg-red-500/10"
              onClick={() => toast({ 
                title: "Account Reset", 
                description: "This feature requires additional confirmation steps.",
                variant: "destructive"
              })}
            >
              Reset
            </Button>
          </div>
        </div>

        {miningData.backupCreated && (
          <div className="mt-4 p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
            <p className="text-green-400 text-sm font-semibold">
              ✅ Wallet backup created successfully!
            </p>
          </div>
        )}

        <div className="mt-4 p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
          <p className="text-yellow-400 text-sm font-semibold">⚠️ Important Security Notice</p>
          <p className="text-gray-300 text-xs mt-1">
            Keep your wallet backup file safe and secure. It contains encrypted data needed to restore your wallet.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default DangerZone;