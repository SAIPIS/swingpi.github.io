import React from 'react';

const ProfileInfo = ({ user, miningData, kycStatus }) => {
  const totalMined = miningData?.total_mined || 0;
  const checkInStreak = miningData?.check_in_streak || 0;

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-gray-400">Mining Phase</span>
          <span className="text-purple-400 font-semibold">Phase {user?.phase || 1}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-400">Total Mined</span>
          <span className="text-green-400 font-semibold">{totalMined.toFixed(2)} SPI</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-400">Check-in Streak</span>
          <span className="text-orange-400 font-semibold">{checkInStreak} days</span>
        </div>
      </div>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-gray-400">Account Status</span>
          <span className="text-green-400 font-semibold">Active</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-400">Verification</span>
          <span className={`font-semibold ${kycStatus.color}`}>{kycStatus.status}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-gray-400">Security Level</span>
          <span className="text-blue-400 font-semibold">Standard</span>
        </div>
      </div>
    </div>
  );
};

export default ProfileInfo;