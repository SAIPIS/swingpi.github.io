import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, Eye, User, Award, Loader2 } from 'lucide-react';

const KycVerification = ({ user, handleKYCVerification, kycStatus, isKycLoading }) => {
  return (
    <Card className="glass-effect border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Shield className="w-5 h-5 mr-2 text-green-400" />
          KYC Verification
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-white">Identity Verification</h3>
            <p className="text-gray-400 text-sm">
              {user.phase >= 3
                ? 'KYC verification is required to unlock your coins and access advanced features.'
                : 'KYC verification will be available when you reach Phase 3.'
              }
            </p>
          </div>
          <div className={`px-3 py-1 rounded-full text-sm font-semibold ${kycStatus.bg} ${kycStatus.color}`}>
            {isKycLoading ? 'Verifying...' : kycStatus.status}
          </div>
        </div>

        {user.phase >= 3 && user.kycStatus !== 'verified' && (
          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-800/50 rounded-lg">
                <Eye className="w-8 h-8 text-blue-400 mb-2" />
                <h4 className="text-white font-semibold">ID Verification</h4>
                <p className="text-gray-400 text-sm">Upload government-issued ID</p>
              </div>
              <div className="p-4 bg-slate-800/50 rounded-lg">
                <User className="w-8 h-8 text-purple-400 mb-2" />
                <h4 className="text-white font-semibold">Face Verification</h4>
                <p className="text-gray-400 text-sm">Complete facial recognition scan</p>
              </div>
            </div>
            
            <Button
              onClick={handleKYCVerification}
              disabled={isKycLoading}
              className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 disabled:opacity-50"
            >
              {isKycLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Verifying with SPI AI...
                </>
              ) : (
                <>
                  <Shield className="w-4 h-4 mr-2" />
                  Start AI KYC Verification
                </>
              )}
            </Button>
          </div>
        )}

        {user.kycStatus === 'verified' && (
          <div className="text-center py-4">
            <Award className="w-16 h-16 text-green-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-green-400 mb-2">Verification Complete!</h3>
            <p className="text-gray-400">Your identity has been successfully verified by SPI AI.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default KycVerification;