import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FileText, Download, Shield, Users, TrendingUp, Lock, Loader2 } from 'lucide-react';
import { useWallet } from '@/contexts/WalletContext';
import { useToast } from '@/components/ui/use-toast';

const Whitepaper = () => {
  const { founderWallet } = useWallet();
  const { toast } = useToast();

  const downloadWhitepaper = () => {
    toast({
      title: "🚧 Whitepaper download isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  if (!founderWallet) {
    return (
      <Card className="glass-effect border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <FileText className="w-5 h-5 mr-2 text-blue-400" />
            SPI Coin Whitepaper & Tokenomics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-8">
            <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
            <p className="ml-4 text-white">Loading Tokenomics...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-effect border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <FileText className="w-5 h-5 mr-2 text-blue-400" />
          SPI Coin Whitepaper & Tokenomics
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="p-4 bg-orange-500/10 border border-orange-500/30 rounded-lg">
          <h3 className="text-orange-400 font-semibold mb-2 flex items-center">
            <Lock className="w-5 h-5 mr-2" />
            Founder Wallet Status
          </h3>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-400">Locked Coins (35%)</p>
              <p className="text-orange-400 font-semibold">{Number(founderWallet.total_locked).toFixed(2)} SPI</p>
            </div>
            <div>
              <p className="text-gray-400">Development Fund (15%)</p>
              <p className="text-green-400 font-semibold">{Number(founderWallet.development_fund).toFixed(2)} SPI</p>
            </div>
          </div>
          <p className="text-gray-400 text-xs mt-2">
            Last migration: {founderWallet.last_migration ? new Date(founderWallet.last_migration).toLocaleString() : 'Never'}
          </p>
        </div>

        <div className="space-y-4">
          <div className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
            <h3 className="text-blue-400 font-semibold mb-2">🔒 Proof of Work & Privacy</h3>
            <p className="text-gray-300 text-sm">
              SPI Coin utilizes a hybrid consensus mechanism combining Proof of Work mining with 
              advanced privacy features. All transactions are secured through cryptographic protocols 
              ensuring user anonymity while maintaining network integrity.
            </p>
          </div>

          <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
            <h3 className="text-green-400 font-semibold mb-2">📊 Token Distribution</h3>
            <ul className="text-gray-300 text-sm space-y-1">
              <li>• 35% Founder Wallet: Automatically locked during mining process</li>
              <li>• 15% Ecosystem Growth: Development fund for partnerships and growth</li>
              <li>• 50% Public Mining: Distributed through 3-phase mining program</li>
            </ul>
          </div>

          <div className="p-4 bg-purple-500/10 border border-purple-500/30 rounded-lg">
            <h3 className="text-purple-400 font-semibold mb-2">🚀 Mining Phases</h3>
            <ul className="text-gray-300 text-sm space-y-1">
              <li>• Phase 1: 3 months, 2.64 SPI/day (Entry level)</li>
              <li>• Phase 2: 3 months, 2.88 SPI/day (Wallet generation unlocked)</li>
              <li>• Phase 3: 4 months, 3.12 SPI/day (Trading unlocked with KYC)</li>
            </ul>
          </div>

          <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
            <h3 className="text-yellow-400 font-semibold mb-2">🔐 Privacy Policy</h3>
            <p className="text-gray-300 text-sm">
              We implement zero-knowledge proofs for transaction privacy, end-to-end encryption 
              for user data, and decentralized storage for maximum security. KYC data is processed 
              through secure third-party providers and never stored on our servers.
            </p>
          </div>
        </div>

        <div className="text-center">
          <Button
            onClick={downloadWhitepaper}
            className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
          >
            <Download className="w-4 h-4 mr-2" />
            Download Full Whitepaper
          </Button>
          <p className="text-gray-400 text-xs mt-2">
            Complete technical documentation and roadmap
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default Whitepaper;