import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Wallet, Copy, Shield } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet } from '@/contexts/WalletContext';
import { useToast } from '@/components/ui/use-toast';

const WalletGeneration = () => {
  const { user } = useAuth();
  const { miningData } = useWallet();
  const { toast } = useToast();

  const generateWalletAddress = () => {
    return `0x${user.id.toString(16)}${Math.random().toString(16).substr(2, 32)}`.padEnd(42, '0');
  };

  const copyAddress = (address) => {
    navigator.clipboard.writeText(address);
    toast({
      title: "Address Copied! 📋",
      description: "Wallet address copied to clipboard",
    });
  };

  if (user?.phase < 2) {
    return (
      <Card className="glass-effect border-gray-500/30">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Wallet className="w-5 h-5 mr-2 text-gray-400" />
            Wallet Generation
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <Shield className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">Wallet Locked</h3>
          <p className="text-gray-400 mb-4">Wallet generation will be unlocked in Phase 2</p>
          <div className="p-4 bg-gray-500/10 border border-gray-500/30 rounded-lg">
            <p className="text-gray-400 text-sm">
              🔒 Current Phase: {user?.phase || 1} | Required: Phase 2+
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  const walletAddresses = {
    BEP20: generateWalletAddress(),
    ERC20: generateWalletAddress(),
    PI: `PI${user.id}${Math.random().toString(36).substr(2, 8).toUpperCase()}`
  };

  return (
    <Card className="glass-effect border-green-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Wallet className="w-5 h-5 mr-2 text-green-400" />
          Multi-Chain Wallet Addresses
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg mb-4">
          <p className="text-green-400 text-sm font-semibold">
            ✅ Wallet Generation Unlocked! (Phase {user.phase})
          </p>
        </div>

        {Object.entries(walletAddresses).map(([network, address]) => (
          <motion.div
            key={network}
            whileHover={{ scale: 1.02 }}
            className="p-4 bg-slate-800/50 rounded-lg"
          >
            <div className="flex justify-between items-center mb-2">
              <h4 className="text-white font-semibold">{network} Network</h4>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => copyAddress(address)}
                className="text-purple-400 hover:text-purple-300"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <code className="text-purple-400 text-sm break-all">{address}</code>
            <p className="text-gray-400 text-xs mt-2">
              {network === 'PI' ? 'PI Network Address' : `${network} Compatible Address`}
            </p>
          </motion.div>
        ))}

        <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
          <h4 className="text-blue-400 font-semibold mb-2">Supported Networks</h4>
          <div className="grid grid-cols-3 gap-2 text-sm">
            <div className="text-center">
              <p className="text-white">BEP20</p>
              <p className="text-gray-400 text-xs">Binance Smart Chain</p>
            </div>
            <div className="text-center">
              <p className="text-white">ERC20</p>
              <p className="text-gray-400 text-xs">Ethereum Network</p>
            </div>
            <div className="text-center">
              <p className="text-white">PI Network</p>
              <p className="text-gray-400 text-xs">PI Blockchain</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WalletGeneration;