import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, Send, X, Bot } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const AIChat = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: "Hi! I'm your SPI AI assistant. I can help you with wallet management, trading tips, mining questions, and blockchain education. How can I assist you today?",
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const { toast } = useToast();

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage = {
      id: Date.now(),
      text: inputValue,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');

    // Simulate AI response
    setTimeout(() => {
      const botResponse = {
        id: Date.now() + 1,
        text: generateAIResponse(inputValue),
        isBot: true,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  const generateAIResponse = (input) => {
    const responses = {
      mining: "Your current mining phase allows you to earn 2.64 SPI coins every 24 hours. Remember to check in daily for bonus rewards! The next phase will increase your mining rate to 2.88 SPI/day.",
      trading: "Based on current market trends, consider diversifying your portfolio. The SPI/USDT pair shows strong potential. Always remember to only invest what you can afford to lose!",
      wallet: "Your wallet is secure with our advanced encryption. For additional security, enable biometric authentication in your profile settings. Never share your private keys!",
      kyc: "KYC verification starts at Phase 3 and helps secure your account. You'll need to provide ID and face verification. This process typically takes 24-48 hours.",
      blockchain: "Blockchain is a distributed ledger technology that ensures transparency and security. Each transaction is recorded in blocks that are linked together, making it nearly impossible to alter past records.",
      default: "I'm here to help with all your SPI Wallet needs! You can ask me about mining, trading, wallet security, KYC verification, or general blockchain questions. What would you like to know more about?"
    };

    const lowerInput = input.toLowerCase();
    if (lowerInput.includes('mine') || lowerInput.includes('mining')) return responses.mining;
    if (lowerInput.includes('trade') || lowerInput.includes('trading')) return responses.trading;
    if (lowerInput.includes('wallet') || lowerInput.includes('security')) return responses.wallet;
    if (lowerInput.includes('kyc') || lowerInput.includes('verification')) return responses.kyc;
    if (lowerInput.includes('blockchain') || lowerInput.includes('crypto')) return responses.blockchain;
    
    return responses.default;
  };

  return (
    <>
      <motion.button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-20 right-4 md:bottom-4 z-40 bg-gradient-to-r from-purple-500 to-pink-500 text-white p-4 rounded-full shadow-lg"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        animate={{ 
          boxShadow: ['0 0 20px rgba(168, 85, 247, 0.5)', '0 0 30px rgba(236, 72, 153, 0.5)', '0 0 20px rgba(168, 85, 247, 0.5)']
        }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <MessageCircle className="w-6 h-6" />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            className="fixed bottom-4 right-4 w-80 h-96 bg-slate-900/95 backdrop-blur-xl border border-purple-500/30 rounded-2xl shadow-2xl z-50 flex flex-col"
          >
            <div className="flex items-center justify-between p-4 border-b border-purple-500/30">
              <div className="flex items-center space-x-2">
                <Bot className="w-6 h-6 text-purple-400" />
                <span className="font-semibold text-white">SPI AI Assistant</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}
                >
                  <div className={`max-w-[80%] p-3 rounded-2xl ${
                    message.isBot 
                      ? 'bg-purple-500/20 text-white' 
                      : 'bg-gradient-to-r from-purple-500 to-pink-500 text-white'
                  }`}>
                    <p className="text-sm">{message.text}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="p-4 border-t border-purple-500/30">
              <div className="flex space-x-2">
                <Input
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="Ask me anything..."
                  className="flex-1 bg-slate-800 border-purple-500/30 text-white"
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                />
                <Button
                  onClick={handleSendMessage}
                  className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default AIChat;