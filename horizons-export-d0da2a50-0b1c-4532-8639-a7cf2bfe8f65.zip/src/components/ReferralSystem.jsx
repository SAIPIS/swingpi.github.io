import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Copy, Users, Gift } from 'lucide-react';
import { useWallet } from '@/contexts/WalletContext';
import { useToast } from '@/components/ui/use-toast';

const ReferralSystem = () => {
  const { miningData, addReferral } = useWallet();
  const { toast } = useToast();
  const [referralInput, setReferralInput] = useState('');

  const copyReferralCode = () => {
    navigator.clipboard.writeText(miningData.referralCode);
    toast({
      title: "Referral Code Copied! 📋",
      description: "Share this code with friends to earn bonuses!",
    });
  };

  const handleApplyReferral = () => {
    if (!referralInput.trim()) {
      toast({
        title: "Invalid Code",
        description: "Please enter a valid referral code",
        variant: "destructive"
      });
      return;
    }

    const result = addReferral(referralInput);
    if (result.success) {
      toast({
        title: "Referral Applied! 🎉",
        description: result.message,
      });
      setReferralInput('');
    } else {
      toast({
        title: "Referral Failed",
        description: result.message,
        variant: "destructive"
      });
    }
  };

  return (
    <Card className="glass-effect border-purple-500/30">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Users className="w-5 h-5 mr-2 text-blue-400" />
          Referral System
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h3 className="text-lg font-semibold text-white mb-3">Your Referral Code</h3>
          <div className="flex items-center space-x-2 bg-slate-800 p-3 rounded-lg">
            <code className="text-purple-400 font-bold flex-1">{miningData.referralCode}</code>
            <Button
              variant="ghost"
              size="sm"
              onClick={copyReferralCode}
              className="text-purple-400 hover:text-purple-300"
            >
              <Copy className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-gray-400 text-sm mt-2">
            Share this code with friends. When they sign up, you both get +0.1 SPI bonus per mining session!
          </p>
        </div>

        {!miningData.referredBy && (
          <div>
            <h3 className="text-lg font-semibold text-white mb-3">Enter Referral Code</h3>
            <div className="flex space-x-2">
              <Input
                value={referralInput}
                onChange={(e) => setReferralInput(e.target.value)}
                placeholder="Enter referral code"
                className="bg-slate-800 border-purple-500/30 text-white"
              />
              <Button
                onClick={handleApplyReferral}
                className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600"
              >
                Apply
              </Button>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-4 bg-slate-800/50 rounded-lg">
            <Gift className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <p className="text-white font-semibold">Bonus Rate</p>
            <p className="text-green-400 text-lg">+{miningData.referralBonus} SPI</p>
            <p className="text-gray-400 text-xs">per mining session</p>
          </div>
          <div className="text-center p-4 bg-slate-800/50 rounded-lg">
            <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <p className="text-white font-semibold">Status</p>
            <p className="text-blue-400 text-lg">
              {miningData.referredBy ? 'Active' : 'None'}
            </p>
            <p className="text-gray-400 text-xs">referral bonus</p>
          </div>
        </div>

        {miningData.referredBy && (
          <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
            <p className="text-green-400 text-sm font-semibold">
              ✅ You're earning +0.1 SPI bonus from referral code: {miningData.referredBy}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ReferralSystem;