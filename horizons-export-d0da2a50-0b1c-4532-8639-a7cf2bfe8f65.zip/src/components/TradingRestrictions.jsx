import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, Lock, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet } from '@/contexts/WalletContext';
import { useNavigate } from 'react-router-dom';

const TradingRestrictions = () => {
  const { user } = useAuth();
  const { canTrade } = useWallet();
  const navigate = useNavigate();

  if (canTrade()) {
    return (
      <Card className="glass-effect border-green-500/30">
        <CardContent className="p-4 text-center">
          <Shield className="w-8 h-8 text-green-400 mx-auto mb-2" />
          <p className="text-green-400 font-semibold">Trading Unlocked</p>
          <p className="text-gray-400 text-sm">All trading features are available</p>
        </CardContent>
      </Card>
    );
  }

  const needsPhase3 = user?.phase < 3;
  const needsKYC = user?.phase >= 3 && user?.kycStatus !== 'verified';

  return (
    <Card className="glass-effect border-red-500/30">
      <CardHeader>
        <CardTitle className="text-red-400 flex items-center">
          <Lock className="w-5 h-5 mr-2" />
          Trading Restrictions
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
          <AlertTriangle className="w-6 h-6 text-red-400 mb-2" />
          <p className="text-red-400 font-semibold mb-2">Trading Features Locked</p>
          <p className="text-gray-400 text-sm">
            Withdraw, Swap, and P2P Trading are restricted until requirements are met.
          </p>
        </div>

        <div className="space-y-3">
          <div className={`flex items-center justify-between p-3 rounded-lg ${
            needsPhase3 ? 'bg-red-500/10 border border-red-500/30' : 'bg-green-500/10 border border-green-500/30'
          }`}>
            <div>
              <p className="text-white font-medium">Phase 3 Required</p>
              <p className="text-gray-400 text-sm">Reach Phase 3 mining level</p>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-semibold ${
              needsPhase3 ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'
            }`}>
              {needsPhase3 ? `Phase ${user?.phase || 1}` : '✓ Complete'}
            </div>
          </div>

          <div className={`flex items-center justify-between p-3 rounded-lg ${
            needsKYC ? 'bg-red-500/10 border border-red-500/30' : 'bg-green-500/10 border border-green-500/30'
          }`}>
            <div>
              <p className="text-white font-medium">KYC Verification</p>
              <p className="text-gray-400 text-sm">Complete identity verification</p>
            </div>
            <div className={`px-3 py-1 rounded-full text-sm font-semibold ${
              needsKYC ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'
            }`}>
              {needsKYC ? user?.kycStatus || 'Pending' : '✓ Verified'}
            </div>
          </div>
        </div>

        {user?.phase >= 3 && needsKYC && (
          <Button
            onClick={() => navigate('/profile')}
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600"
          >
            Complete KYC Verification
          </Button>
        )}

        <div className="text-center text-gray-400 text-sm">
          <p>Your SPI coins are locked until trading is unlocked</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default TradingRestrictions;