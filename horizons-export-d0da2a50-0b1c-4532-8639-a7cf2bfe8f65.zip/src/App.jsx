import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Toaster } from '@/components/ui/toaster';
import Dashboard from '@/pages/Dashboard';
import Mining from '@/pages/Mining';
import Wallet from '@/pages/Wallet';
import Trading from '@/pages/Trading';
import Profile from '@/pages/Profile';
import Auth from '@/pages/Auth';
import { AuthProvider } from '@/contexts/AuthContext';
import { WalletProvider } from '@/contexts/WalletContext';

function App() {
  return (
    <AuthProvider>
      <WalletProvider>
        <Router>
          <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
            <Helmet>
              <title>SPI Wallet - Smart Crypto Mining & Trading</title>
              <meta name="description" content="SPI Wallet - The ultimate AI-powered crypto wallet with smart mining, trading, and secure blockchain transactions." />
            </Helmet>
            
            <Routes>
              <Route path="/auth" element={<Auth />} />
              <Route path="/" element={<Dashboard />} />
              <Route path="/mining" element={<Mining />} />
              <Route path="/wallet" element={<Wallet />} />
              <Route path="/trading" element={<Trading />} />
              <Route path="/profile" element={<Profile />} />
            </Routes>
            
            <Toaster />
          </div>
        </Router>
      </WalletProvider>
    </AuthProvider>
  );
}

export default App;