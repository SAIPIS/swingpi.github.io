import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Shovel as Pickaxe, Gift, Clock, Zap, TrendingUp, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import AIChat from '@/components/AIChat';
import ReferralSystem from '@/components/ReferralSystem';
import WalletGeneration from '@/components/WalletGeneration';
import TradingRestrictions from '@/components/TradingRestrictions';
import Whitepaper from '@/components/Whitepaper';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet } from '@/contexts/WalletContext';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';

const Mining = () => {
  const { user } = useAuth();
  const { miningData, mine, checkIn, isLoading } = useWallet();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [timeUntilNextMine, setTimeUntilNextMine] = useState('');
  const [isMining, setIsMining] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    
    if (!miningData) return;

    const updateTimer = () => {
      if (miningData.last_mined) {
        const lastMined = new Date(miningData.last_mined);
        const nextMine = new Date(lastMined.getTime() + 24 * 60 * 60 * 1000);
        const now = new Date();
        const diff = nextMine - now;

        if (diff > 0) {
          const hours = Math.floor(diff / (1000 * 60 * 60));
          const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((diff % (1000 * 60)) / 1000);
          setTimeUntilNextMine(`${hours}h ${minutes}m ${seconds}s`);
        } else {
          setTimeUntilNextMine('');
        }
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [user, navigate, miningData]);

  if (!user || isLoading || !miningData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-purple-400 animate-spin" />
      </div>
    );
  }

  const handleMine = async () => {
    setIsMining(true);
    
    setTimeout(async () => {
      const result = await mine();
      if (result.success) {
        toast({
          title: "Mining Successful! ⛏️",
          description: `You earned ${result.amount} SPI coins!${miningData.referral_bonus > 0 ? ` (Including +${miningData.referral_bonus} referral bonus)` : ''}`,
        });
      } else {
        toast({
          title: "Mining Failed",
          description: result.message,
          variant: "destructive"
        });
      }
      setIsMining(false);
    }, 2000);
  };

  const handleCheckIn = async () => {
    const result = await checkIn();
    if (result.success) {
      toast({
        title: `Daily Check-in Reward! 🎁`,
        description: `Day ${result.streak}: +${result.reward} SPI coins!`,
      });
    } else {
      toast({
        title: "Check-in Failed",
        description: result.message,
        variant: "destructive"
      });
    }
  };

  const canMine = !miningData.last_mined || new Date() - new Date(miningData.last_mined) >= 24 * 60 * 60 * 1000;
  const canCheckIn = !miningData.last_check_in || new Date() - new Date(miningData.last_check_in) >= 24 * 60 * 60 * 1000;

  const phaseInfo = {
    1: { duration: '3 months', rate: 2.64, color: 'text-green-400' },
    2: { duration: '3 months', rate: 2.88, color: 'text-blue-400' },
    3: { duration: '4 months', rate: 3.12, color: 'text-purple-400' }
  };

  const checkInRewards = [0.19, 0.29, 0.39, 0.49, 0.59, 0.69, 0.79];
  const totalEarnings = parseFloat(miningData.daily_rate) + parseFloat(miningData.referral_bonus);

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:pl-20">
      <Helmet>
        <title>Mining - SPI Wallet</title>
        <meta name="description" content="Mine SPI coins with our AI-enhanced mining system. Earn daily rewards and track your mining progress." />
      </Helmet>
      
      <Navigation />
      
      <div className="p-4 md:p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="text-center">
            <h1 className="text-3xl font-bold gradient-text mb-2">SPI Mining Center</h1>
            <p className="text-gray-400">Mine SPI coins with one click every 24 hours</p>
          </div>

          <Card className="glass-effect border-purple-500/30 mining-glow">
            <CardContent className="p-8 text-center">
              <motion.div
                animate={isMining ? { 
                  scale: [1, 1.1, 1],
                  rotate: [0, 10, -10, 0]
                } : {}}
                transition={{ duration: 0.5, repeat: isMining ? Infinity : 0 }}
                className="mb-6"
              >
                <Pickaxe className="w-24 h-24 text-purple-400 mx-auto" />
              </motion.div>
              
              <h2 className="text-2xl font-bold text-white mb-4">
                {isMining ? 'Mining in Progress...' : canMine ? 'Ready to Mine!' : 'Mining Cooldown'}
              </h2>
              
              {!canMine && timeUntilNextMine && (
                <p className="text-orange-400 mb-4">
                  Next mining available in: {timeUntilNextMine}
                </p>
              )}
              
              <Button
                onClick={handleMine}
                disabled={!canMine || isMining}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold py-4 px-8 text-lg disabled:opacity-50"
              >
                {isMining ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  >
                    <Zap className="w-6 h-6 mr-2" />
                  </motion.div>
                ) : (
                  <Pickaxe className="w-6 h-6 mr-2" />
                )}
                {isMining ? 'Mining...' : canMine ? 'MINE NOW' : 'Mining Unavailable'}
              </Button>
              
              <div className="mt-4 space-y-2">
                <p className="text-gray-400">
                  Base Rate: {miningData.daily_rate} SPI
                </p>
                {miningData.referral_bonus > 0 && (
                  <p className="text-green-400">
                    Referral Bonus: +{miningData.referral_bonus} SPI
                  </p>
                )}
                <p className="text-white font-semibold">
                  Total Earnings: {totalEarnings} SPI per session
                </p>
              </div>
            </CardContent>
          </Card>

          <div className="grid md:grid-cols-3 gap-4">
            {Object.entries(phaseInfo).map(([phase, info]) => (
              <Card 
                key={phase}
                className={`glass-effect border-purple-500/30 ${
                  miningData.phase === parseInt(phase) ? 'ring-2 ring-purple-400' : ''
                }`}
              >
                <CardHeader>
                  <CardTitle className={`text-center ${info.color}`}>
                    Phase {phase}
                    {miningData.phase === parseInt(phase) && (
                      <span className="ml-2 text-xs bg-purple-500 px-2 py-1 rounded-full">ACTIVE</span>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-2xl font-bold text-white mb-2">{info.rate} SPI</p>
                  <p className="text-gray-400 text-sm">per 24 hours</p>
                  <p className="text-gray-400 text-xs mt-2">Duration: {info.duration}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="glass-effect border-orange-500/30">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Gift className="w-5 h-5 mr-2 text-orange-400" />
                Daily Check-in Rewards
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-7 gap-2 mb-4">
                {checkInRewards.map((reward, index) => (
                  <div
                    key={index}
                    className={`text-center p-3 rounded-lg ${
                      miningData.check_in_streak > index 
                        ? 'bg-orange-500/20 border border-orange-400' 
                        : 'bg-white/5 border border-gray-600'
                    }`}
                  >
                    <p className="text-xs text-gray-400">Day {index + 1}</p>
                    <p className="text-sm font-semibold text-white">{reward}</p>
                    <p className="text-xs text-gray-400">SPI</p>
                  </div>
                ))}
              </div>
              
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-white">Current Streak: {miningData.check_in_streak} days</p>
                  <p className="text-gray-400 text-sm">
                    Next reward: {checkInRewards[Math.min(miningData.check_in_streak, 6)]} SPI
                  </p>
                </div>
                <Button
                  onClick={handleCheckIn}
                  disabled={!canCheckIn}
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 disabled:opacity-50"
                >
                  <Gift className="w-4 h-4 mr-2" />
                  {canCheckIn ? 'Check In' : 'Already Checked'}
                </Button>
              </div>
            </CardContent>
          </Card>

          <ReferralSystem />
          <WalletGeneration />
          <TradingRestrictions />
          <Whitepaper />

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="glass-effect border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
                  Mining Statistics
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Total Mined</span>
                    <span className="text-green-400 font-semibold">{Number(miningData.total_mined).toFixed(2)} SPI</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Current Phase</span>
                    <span className="text-purple-400 font-semibold">Phase {miningData.phase}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Daily Rate</span>
                    <span className="text-blue-400 font-semibold">{totalEarnings} SPI/day</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Check-in Streak</span>
                    <span className="text-orange-400 font-semibold">{miningData.check_in_streak} days</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-effect border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-blue-400" />
                  Mining Schedule
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="text-gray-400 text-sm">Last Mining Session</p>
                    <p className="text-white">
                      {miningData.last_mined
                        ? new Date(miningData.last_mined).toLocaleString()
                        : 'Never'
                      }
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Next Available</p>
                    <p className="text-white">
                      {canMine ? 'Now' : timeUntilNextMine || 'Calculating...'}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm">Last Check-in</p>
                    <p className="text-white">
                      {miningData.last_check_in 
                        ? new Date(miningData.last_check_in).toLocaleDateString()
                        : 'Never'
                      }
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </div>

      <AIChat />
    </div>
  );
};

export default Mining;