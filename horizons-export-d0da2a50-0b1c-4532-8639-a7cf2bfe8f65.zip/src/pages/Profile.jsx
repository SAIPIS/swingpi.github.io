import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { User, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import Navigation from '@/components/Navigation';
import AIChat from '@/components/AIChat';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet } from '@/contexts/WalletContext';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';

import ProfileHeader from '@/components/profile/ProfileHeader';
import ProfileInfo from '@/components/profile/ProfileInfo';
import ProfileEditForm from '@/components/profile/ProfileEditForm';
import KycVerification from '@/components/profile/KycVerification';
import SecuritySettings from '@/components/profile/SecuritySettings';
import AdvancedSettings from '@/components/profile/AdvancedSettings';
import AccountStats from '@/components/profile/AccountStats';
import DangerZone from '@/components/profile/DangerZone';

const Profile = () => {
  const { user, updateUser } = useAuth();
  const { miningData, isLoading: isWalletLoading } = useWallet();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [isKycLoading, setIsKycLoading] = useState(false);
  const [profileData, setProfileData] = useState({
    name: user?.name || '',
    email: user?.email || ''
  });
  const [settings, setSettings] = useState({
    notifications: true,
    biometric: false,
    darkMode: true,
    autoKyc: user?.phase >= 3,
    autoBackup: false,
    transactionNotifications: true,
    privacyMode: false
  });

  useEffect(() => {
    if (!user) {
      navigate('/auth');
    } else {
      setProfileData({ name: user.name, email: user.email });
      setSettings(prev => ({...prev, biometric: user.biometric_setup}));
    }
  }, [user, navigate]);

  if (!user || isWalletLoading || !miningData) {
     return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-purple-400 animate-spin" />
      </div>
    );
  }

  const handleSaveProfile = async () => {
    await updateUser({ name: profileData.name });
    setIsEditing(false);
    toast({
      title: "Profile Updated! ✅",
      description: "Your profile information has been saved successfully.",
    });
  };

  const handleKYCVerification = () => {
    if (user.phase < 3) {
      toast({
        title: "KYC Not Available",
        description: "KYC verification is only available from Phase 3 onwards.",
        variant: "destructive"
      });
      return;
    }
    setIsKycLoading(true);
    toast({
      title: "🤖 SPI AI is verifying your identity...",
      description: "This may take a few moments. Please wait.",
    });
  
    setTimeout(async () => {
      await updateUser({ kyc_status: 'verified' });
      setIsKycLoading(false);
      toast({
        title: "✅ KYC Verified!",
        description: "SPI AI has approved your profile. All features are now unlocked.",
      });
    }, 3500);
  };

  const getKYCStatus = () => {
    if (user.phase < 3) return { status: 'Not Available', color: 'text-gray-400', bg: 'bg-gray-500/20' };
    if (user.kyc_status === 'pending') return { status: 'Pending', color: 'text-yellow-400', bg: 'bg-yellow-500/20' };
    if (user.kyc_status === 'verified') return { status: 'Verified', color: 'text-green-400', bg: 'bg-green-500/20' };
    return { status: 'Required', color: 'text-red-400', bg: 'bg-red-500/20' };
  };

  const kycStatus = getKYCStatus();

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:pl-20">
      <Helmet>
        <title>Profile - SPI Wallet</title>
        <meta name="description" content="Manage your SPI Wallet profile, security settings, and KYC verification status." />
      </Helmet>
      
      <Navigation />
      
      <div className="p-4 md:p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="text-center">
            <h1 className="text-3xl font-bold gradient-text mb-2">My Profile</h1>
            <p className="text-gray-400">Manage your account and security settings</p>
          </div>

          <Card className="glass-effect border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <User className="w-5 h-5 mr-2 text-purple-400" />
                Profile Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ProfileHeader user={user} isEditing={isEditing} setIsEditing={setIsEditing} />
              {isEditing ? (
                <ProfileEditForm 
                  profileData={profileData} 
                  setProfileData={setProfileData} 
                  handleSaveProfile={handleSaveProfile} 
                />
              ) : (
                <ProfileInfo user={user} miningData={miningData} kycStatus={kycStatus} />
              )}
            </CardContent>
          </Card>

          <KycVerification 
            user={user} 
            handleKYCVerification={handleKYCVerification} 
            kycStatus={kycStatus}
            isKycLoading={isKycLoading}
          />
          <SecuritySettings settings={settings} setSettings={setSettings} user={user} />
          <AdvancedSettings settings={settings} setSettings={setSettings} />
          <AccountStats user={user} miningData={miningData} />
          <DangerZone />
        </motion.div>
      </div>

      <AIChat />
    </div>
  );
};

export default Profile;