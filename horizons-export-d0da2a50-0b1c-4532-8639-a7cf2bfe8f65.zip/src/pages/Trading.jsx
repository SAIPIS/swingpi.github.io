import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Navigation from '@/components/Navigation';
import AIChat from '@/components/AIChat';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet } from '@/contexts/WalletContext';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';

import TradingHeader from '@/components/trading/TradingHeader';
import QuickActions from '@/components/trading/QuickActions';
import MarketOverview from '@/components/trading/MarketOverview';
import TradingInterface from '@/components/trading/TradingInterface';
import AITradingInsights from '@/components/trading/AITradingInsights';

const Trading = () => {
  const { user } = useAuth();
  const { balances, updateBalance, addTransaction, canTrade } = useWallet();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('swap');
  const [swapForm, setSwapForm] = useState({
    fromCoin: 'USDT',
    toCoin: 'SPI',
    amount: ''
  });

  React.useEffect(() => {
    if (!user) {
      navigate('/auth');
    }
  }, [user, navigate]);

  if (!user) return null;

  const handleSwap = (e) => {
    e.preventDefault();
    
    if (!canTrade()) {
      toast({ 
        title: "Trading Locked", 
        description: "Complete Phase 3 and KYC verification to unlock trading features.",
        variant: "destructive" 
      });
      return;
    }
    
    const amount = parseFloat(swapForm.amount);
    if (!amount || amount <= 0) {
      toast({ title: "Invalid Amount", description: "Please enter a valid amount", variant: "destructive" });
      return;
    }

    if (amount > balances[swapForm.fromCoin]) {
      toast({ title: "Insufficient Balance", description: `You don't have enough ${swapForm.fromCoin}`, variant: "destructive" });
      return;
    }

    const fee = amount * 0.003;
    const amountAfterFee = amount - fee;
    const exchangeRate = swapForm.fromCoin === 'USDT' ? 8.33 : 0.12;
    const receivedAmount = amountAfterFee * exchangeRate;

    updateBalance(swapForm.fromCoin, -amount);
    updateBalance(swapForm.toCoin, receivedAmount);

    addTransaction({
      type: 'swap',
      amount: amount,
      coin: swapForm.fromCoin,
      receivedAmount: receivedAmount,
      receivedCoin: swapForm.toCoin,
      fee: fee,
      status: 'completed'
    });

    toast({ title: "Swap Successful! 🔄", description: `Swapped ${amount} ${swapForm.fromCoin} for ${receivedAmount.toFixed(2)} ${swapForm.toCoin}` });
    setSwapForm({ ...swapForm, amount: '' });
  };

  const handleP2PTrade = () => {
    if (!canTrade()) {
      toast({ 
        title: "P2P Trading Locked", 
        description: "Complete Phase 3 and KYC verification to unlock P2P trading.",
        variant: "destructive" 
      });
      return;
    }
    setActiveTab('p2p');
    toast({ title: "🚧 P2P Trading isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" });
  };

  const handleDeposit = () => {
    if (!canTrade()) {
      toast({ 
        title: "Deposit Locked", 
        description: "Complete Phase 3 and KYC verification to unlock deposit features.",
        variant: "destructive" 
      });
      return;
    }
    toast({ title: "🚧 Deposit feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" });
  };

  const handleWithdraw = () => {
    if (!canTrade()) {
      toast({ 
        title: "Withdraw Locked", 
        description: "Complete Phase 3 and KYC verification to unlock withdraw features.",
        variant: "destructive" 
      });
      return;
    }
    toast({ title: "🚧 Withdraw feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀" });
  };

  const handleSwapClick = () => setActiveTab('swap');

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:pl-20">
      <Helmet>
        <title>Trading - SPI Wallet</title>
        <meta name="description" content="Trade cryptocurrencies with AI-powered insights, real-time market data, and secure P2P trading." />
      </Helmet>
      
      <Navigation />
      
      <div className="p-4 md:p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <TradingHeader />
          <QuickActions 
            handleDeposit={handleDeposit} 
            handleWithdraw={handleWithdraw} 
            handleP2PTrade={handleP2PTrade}
            handleSwapClick={handleSwapClick}
          />
          <MarketOverview />
          <TradingInterface 
            swapForm={swapForm}
            setSwapForm={setSwapForm}
            handleSwap={handleSwap}
            balances={balances}
            handleP2PTrade={handleP2PTrade}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
          />
          <AITradingInsights />
        </motion.div>
      </div>

      <AIChat />
    </div>
  );
};

export default Trading;