import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Send, Download, ArrowUpDown, Copy, QrCode, History, Eye, EyeOff } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import Navigation from '@/components/Navigation';
import AIChat from '@/components/AIChat';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet } from '@/contexts/WalletContext';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';

const Wallet = () => {
  const { user } = useAuth();
  const { balances, transactions, addTransaction, updateBalance } = useWallet();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [showBalances, setShowBalances] = useState(true);
  const [sendForm, setSendForm] = useState({
    coin: 'SPI',
    amount: '',
    address: ''
  });

  React.useEffect(() => {
    if (!user) {
      navigate('/auth');
    }
  }, [user, navigate]);

  if (!user) return null;

  const handleSend = (e) => {
    e.preventDefault();
    
    if (!sendForm.amount || !sendForm.address) {
      toast({
        title: "Invalid Input",
        description: "Please fill in all fields",
        variant: "destructive"
      });
      return;
    }

    const amount = parseFloat(sendForm.amount);
    if (amount <= 0 || amount > balances[sendForm.coin]) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough coins for this transaction",
        variant: "destructive"
      });
      return;
    }

    updateBalance(sendForm.coin, -amount);
    addTransaction({
      type: 'send',
      amount: amount,
      coin: sendForm.coin,
      address: sendForm.address,
      status: 'completed'
    });

    toast({
      title: "Transaction Sent! 🚀",
      description: `${amount} ${sendForm.coin} sent successfully`,
    });

    setSendForm({ coin: 'SPI', amount: '', address: '' });
  };

  const handleReceive = () => {
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const handleSwap = () => {
    navigate('/trading');
  };

  const copyAddress = () => {
    const address = `spi_${user.id}_${Date.now()}`;
    navigator.clipboard.writeText(address);
    toast({
      title: "Address Copied! 📋",
      description: "Your wallet address has been copied to clipboard",
    });
  };

  const coins = ['SPI', 'PI', 'USDT'];

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:pl-20">
      <Helmet>
        <title>Wallet - SPI Wallet</title>
        <meta name="description" content="Manage your crypto wallet with secure transactions, multi-coin support, and real-time balance tracking." />
      </Helmet>
      
      <Navigation />
      
      <div className="p-4 md:p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold gradient-text">My Wallet</h1>
              <p className="text-gray-400 mt-1">Manage your crypto assets securely</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowBalances(!showBalances)}
              className="text-gray-400 hover:text-white"
            >
              {showBalances ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {Object.entries(balances).map(([coin, balance]) => (
              <motion.div
                key={coin}
                whileHover={{ scale: 1.02 }}
                className="glass-effect border-purple-500/30 rounded-xl p-4"
              >
                <div className="text-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-3">
                    <span className="text-white font-bold text-sm">{coin}</span>
                  </div>
                  <p className="text-2xl font-bold text-white">
                    {showBalances ? balance.toFixed(2) : '****'}
                  </p>
                  <p className="text-gray-400 text-sm">{coin}</p>
                  <p className="text-green-400 text-xs mt-1">
                    ${showBalances ? (balance * 0.1).toFixed(2) : '****'}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="grid grid-cols-3 gap-4">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Card className="glass-effect border-green-500/30 cursor-pointer hover:border-green-400/50 transition-all">
                <CardContent className="p-4 text-center">
                  <Send className="w-8 h-8 text-green-400 mx-auto mb-2" />
                  <p className="text-white font-semibold">Send</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Card 
                className="glass-effect border-blue-500/30 cursor-pointer hover:border-blue-400/50 transition-all"
                onClick={handleReceive}
              >
                <CardContent className="p-4 text-center">
                  <Download className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                  <p className="text-white font-semibold">Receive</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Card 
                className="glass-effect border-purple-500/30 cursor-pointer hover:border-purple-400/50 transition-all"
                onClick={handleSwap}
              >
                <CardContent className="p-4 text-center">
                  <ArrowUpDown className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                  <p className="text-white font-semibold">Swap</p>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <Tabs defaultValue="send" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-slate-800/50">
              <TabsTrigger value="send" className="text-white">Send</TabsTrigger>
              <TabsTrigger value="receive" className="text-white">Receive</TabsTrigger>
              <TabsTrigger value="history" className="text-white">History</TabsTrigger>
            </TabsList>

            <TabsContent value="send">
              <Card className="glass-effect border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Send className="w-5 h-5 mr-2 text-green-400" />
                    Send Crypto
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSend} className="space-y-4">
                    <div>
                      <label className="text-gray-400 text-sm">Select Coin</label>
                      <select
                        value={sendForm.coin}
                        onChange={(e) => setSendForm({...sendForm, coin: e.target.value})}
                        className="w-full mt-1 p-3 bg-slate-800 border border-purple-500/30 rounded-lg text-white"
                      >
                        {coins.map(coin => (
                          <option key={coin} value={coin}>
                            {coin} (Balance: {balances[coin].toFixed(2)})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-gray-400 text-sm">Amount</label>
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="0.00"
                        value={sendForm.amount}
                        onChange={(e) => setSendForm({...sendForm, amount: e.target.value})}
                        className="mt-1 bg-slate-800 border-purple-500/30 text-white"
                      />
                    </div>

                    <div>
                      <label className="text-gray-400 text-sm">Recipient Address</label>
                      <Input
                        type="text"
                        placeholder="Enter wallet address or Account ID"
                        value={sendForm.address}
                        onChange={(e) => setSendForm({...sendForm, address: e.target.value})}
                        className="mt-1 bg-slate-800 border-purple-500/30 text-white"
                      />
                    </div>

                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      Send Transaction
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="receive">
              <Card className="glass-effect border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Download className="w-5 h-5 mr-2 text-blue-400" />
                    Receive Crypto
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center space-y-4">
                  <div className="bg-white p-4 rounded-lg inline-block">
                    <QrCode className="w-32 h-32 text-black mx-auto" />
                  </div>
                  
                  <div>
                    <p className="text-gray-400 text-sm mb-2">Your Wallet Address</p>
                    <div className="flex items-center space-x-2 bg-slate-800 p-3 rounded-lg">
                      <code className="text-white text-sm flex-1">spi_{user.id}_{Date.now()}</code>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={copyAddress}
                        className="text-purple-400 hover:text-purple-300"
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mt-6">
                    <div className="text-center p-3 bg-slate-800/50 rounded-lg">
                      <p className="text-gray-400 text-sm">On-Chain</p>
                      <p className="text-white text-xs">BEP20, ERC20, PI Network</p>
                    </div>
                    <div className="text-center p-3 bg-slate-800/50 rounded-lg">
                      <p className="text-gray-400 text-sm">Off-Chain</p>
                      <p className="text-white text-xs">Account ID Transfer</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="history">
              <Card className="glass-effect border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <History className="w-5 h-5 mr-2 text-orange-400" />
                    Transaction History
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 max-h-96 overflow-y-auto scrollbar-hide">
                    {transactions.length > 0 ? (
                      transactions.map((tx) => (
                        <div key={tx.id} className="flex justify-between items-center p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-all">
                          <div className="flex items-center space-x-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                              tx.type === 'send' ? 'bg-red-500/20' :
                              tx.type === 'receive' ? 'bg-green-500/20' :
                              tx.type === 'mining' ? 'bg-purple-500/20' :
                              'bg-blue-500/20'
                            }`}>
                              {tx.type === 'send' ? <Send className="w-4 h-4 text-red-400" /> :
                               tx.type === 'receive' ? <Download className="w-4 h-4 text-green-400" /> :
                               tx.type === 'mining' ? '⛏️' : '🎁'}
                            </div>
                            <div>
                              <p className="text-white font-medium capitalize">
                                {tx.type === 'mining' ? 'Mining Reward' :
                                 tx.type === 'checkin' ? `Daily Check-in (Day ${tx.streak})` :
                                 tx.type}
                              </p>
                              <p className="text-gray-400 text-sm">
                                {new Date(tx.timestamp).toLocaleString()}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className={`font-semibold ${
                              tx.type === 'send' ? 'text-red-400' : 'text-green-400'
                            }`}>
                              {tx.type === 'send' ? '-' : '+'}{tx.amount} {tx.coin}
                            </p>
                            <p className="text-gray-400 text-sm">{tx.status}</p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8">
                        <History className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                        <p className="text-gray-400">No transactions yet</p>
                        <p className="text-gray-500 text-sm">Your transaction history will appear here</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>

      <AIChat />
    </div>
  );
};

export default Wallet;