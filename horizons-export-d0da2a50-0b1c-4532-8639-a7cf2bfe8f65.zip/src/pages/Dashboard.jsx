import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Wallet, Shovel as Pickaxe, Users, Eye, EyeOff, Loader2 } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import AIChat from '@/components/AIChat';
import { useAuth } from '@/contexts/AuthContext';
import { useWallet } from '@/contexts/WalletContext';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { Helmet } from 'react-helmet';

const Dashboard = () => {
  const { user } = useAuth();
  const { balances, miningData, transactions, isLoading } = useWallet();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [showBalances, setShowBalances] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/auth');
    }
  }, [user, navigate]);

  if (!user || isLoading || !miningData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-purple-400 animate-spin" />
      </div>
    );
  }

  const totalBalance = Object.values(balances).reduce((sum, balance) => sum + balance, 0);
  const recentTransactions = transactions.slice(0, 3);

  const handleQuickAction = (action) => {
    switch (action) {
      case 'mine':
        navigate('/mining');
        break;
      case 'trade':
        navigate('/trading');
        break;
      case 'wallet':
        navigate('/wallet');
        break;
      default:
        toast({
          title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
        });
    }
  };

  return (
    <div className="min-h-screen pb-20 md:pb-0 md:pl-20">
      <Helmet>
        <title>Dashboard - SPI Wallet</title>
        <meta name="description" content="Your SPI Wallet dashboard with mining stats, balance overview, and trading insights." />
      </Helmet>
      
      <Navigation />
      
      <div className="p-4 md:p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-white">
                Welcome back, {user.name}! 👋
              </h1>
              <p className="text-gray-400 mt-1">Ready to mine some SPI coins today?</p>
            </div>
            <motion.div
              className="coin-spin"
              animate={{ rotateY: 360 }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
            >
              <img 
                src="https://storage.googleapis.com/hostinger-horizons-assets-prod/d0da2a50-0b1c-4532-8639-a7cf2bfe8f65/dea1b9e0cc03f728defec8d4905f734d.jpg" 
                alt="SPI Coin" 
                className="w-12 h-12 rounded-full"
              />
            </motion.div>
          </div>

          <Card className="glass-effect border-purple-500/30 mining-glow">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-white">Portfolio Balance</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowBalances(!showBalances)}
                className="text-gray-400 hover:text-white"
              >
                {showBalances ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="text-3xl font-bold gradient-text">
                    {showBalances ? `$${(totalBalance * 0.12).toFixed(2)}` : '****'}
                  </p>
                  <p className="text-gray-400 text-sm">Total Portfolio Value (USD)</p>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {Object.entries(balances).map(([coin, balance]) => (
                    <div key={coin} className="text-center p-3 rounded-lg bg-white/5">
                      <p className="text-lg font-semibold text-white">
                        {showBalances ? Number(balance).toFixed(2) : '****'}
                      </p>
                      <p className="text-xs text-gray-400">{coin}</p>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Card 
                className="glass-effect border-green-500/30 cursor-pointer hover:border-green-400/50 transition-all"
                onClick={() => handleQuickAction('mine')}
              >
                <CardContent className="p-4 text-center">
                  <Pickaxe className="w-8 h-8 text-green-400 mx-auto mb-2" />
                  <p className="text-white font-semibold">Mine Now</p>
                  <p className="text-xs text-gray-400">Earn SPI coins</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Card 
                className="glass-effect border-blue-500/30 cursor-pointer hover:border-blue-400/50 transition-all"
                onClick={() => handleQuickAction('trade')}
              >
                <CardContent className="p-4 text-center">
                  <TrendingUp className="w-8 h-8 text-blue-400 mx-auto mb-2" />
                  <p className="text-white font-semibold">Trade</p>
                  <p className="text-xs text-gray-400">Buy & Sell</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Card 
                className="glass-effect border-purple-500/30 cursor-pointer hover:border-purple-400/50 transition-all"
                onClick={() => handleQuickAction('wallet')}
              >
                <CardContent className="p-4 text-center">
                  <Wallet className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                  <p className="text-white font-semibold">Wallet</p>
                  <p className="text-xs text-gray-400">Send & Receive</p>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Card 
                className="glass-effect border-orange-500/30 cursor-pointer hover:border-orange-400/50 transition-all"
                onClick={() => handleQuickAction('referral')}
              >
                <CardContent className="p-4 text-center">
                  <Users className="w-8 h-8 text-orange-400 mx-auto mb-2" />
                  <p className="text-white font-semibold">Refer</p>
                  <p className="text-xs text-gray-400">Earn rewards</p>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="glass-effect border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <Pickaxe className="w-5 h-5 mr-2 text-purple-400" />
                  Mining Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Current Phase</span>
                    <span className="text-white font-semibold">Phase {miningData.phase}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Daily Rate</span>
                    <span className="text-green-400 font-semibold">{parseFloat(miningData.daily_rate) + parseFloat(miningData.referral_bonus)} SPI/day</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Total Mined</span>
                    <span className="text-purple-400 font-semibold">{Number(miningData.total_mined).toFixed(2)} SPI</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Check-in Streak</span>
                    <span className="text-orange-400 font-semibold">{miningData.check_in_streak} days</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="glass-effect border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentTransactions.length > 0 ? (
                    recentTransactions.map((tx) => (
                      <div key={tx.id} className="flex justify-between items-center p-2 rounded-lg bg-white/5">
                        <div>
                          <p className="text-white text-sm font-medium">
                            {tx.type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                          </p>
                          <p className="text-gray-400 text-xs">
                            {new Date(tx.timestamp).toLocaleDateString()}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-green-400 font-semibold">+{tx.amount} {tx.coin}</p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-400 text-center py-4">No recent activity</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="glass-effect border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-white">Follow SPI Community</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-4">
                <Button
                  variant="outline"
                  className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
                  onClick={() => window.open('https://twitter.com/swingpico', '_blank')}
                >
                  🐦 Twitter
                </Button>
                <Button
                  variant="outline"
                  className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
                  onClick={() => window.open('https://t.me/swingpicom', '_blank')}
                >
                  📱 Telegram
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <AIChat />
    </div>
  );
};

export default Dashboard;