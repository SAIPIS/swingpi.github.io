import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';

const WalletContext = createContext();

export const useWallet = () => {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};

export const WalletProvider = ({ children }) => {
  const { user } = useAuth();
  const [balances, setBalances] = useState({ SPI: 0, PI: 0, USDT: 0 });
  const [miningData, setMiningData] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [founderWallet, setFounderWallet] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (user) {
        setIsLoading(true);
        try {
          const [balancesRes, miningRes, transactionsRes, founderRes] = await Promise.all([
            supabase.from('wallets').select('*').eq('user_id', user.id),
            supabase.from('mining_data').select('*').eq('user_id', user.id).single(),
            supabase.from('transactions').select('*').eq('user_id', user.id).order('timestamp', { ascending: false }),
            supabase.from('founder_wallet').select('*').eq('id', 1).single()
          ]);

          if (balancesRes.error) throw balancesRes.error;
          const userBalances = { SPI: 0, PI: 0, USDT: 0 };
          balancesRes.data.forEach(wallet => {
            userBalances[wallet.coin] = parseFloat(wallet.balance);
          });
          setBalances(userBalances);

          if (miningRes.error) throw miningRes.error;
          setMiningData(miningRes.data);

          if (transactionsRes.error) throw transactionsRes.error;
          setTransactions(transactionsRes.data);
          
          if (founderRes.error) throw founderRes.error;
          setFounderWallet(founderRes.data);

        } catch (error) {
          console.error("Error fetching wallet data:", error);
        } finally {
          setIsLoading(false);
        }
      } else {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [user]);

  const updateBalance = async (coin, amountChange) => {
    const currentBalance = balances[coin];
    const newBalance = currentBalance + amountChange;
    
    const { error } = await supabase
      .from('wallets')
      .update({ balance: newBalance })
      .eq('user_id', user.id)
      .eq('coin', coin);
      
    if (error) throw error;
    setBalances(prev => ({ ...prev, [coin]: newBalance }));
  };

  const addTransaction = async (txData) => {
    const { data, error } = await supabase
      .from('transactions')
      .insert({ user_id: user.id, ...txData })
      .select()
      .single();

    if (error) throw error;
    setTransactions(prev => [data, ...prev]);
  };
  
  const mine = async () => {
    const now = new Date();
    const lastMined = miningData.last_mined ? new Date(miningData.last_mined) : null;
    
    if (lastMined && now - lastMined < 24 * 60 * 60 * 1000) {
      return { success: false, message: 'You can only mine once every 24 hours!' };
    }

    const totalEarnings = parseFloat(miningData.daily_rate) + parseFloat(miningData.referral_bonus);
    
    const newTotalMined = parseFloat(miningData.total_mined) + totalEarnings;
    const newLastMined = now.toISOString();

    const { error: miningError } = await supabase
      .from('mining_data')
      .update({ total_mined: newTotalMined, last_mined: newLastMined })
      .eq('user_id', user.id);
      
    if (miningError) throw miningError;

    setMiningData(prev => ({ ...prev, total_mined: newTotalMined, last_mined: newLastMined }));
    
    await updateBalance('SPI', totalEarnings);
    await addTransaction({
        type: 'mining',
        amount: totalEarnings,
        coin: 'SPI',
        details: { base: miningData.daily_rate, referralBonus: miningData.referral_bonus }
    });

    const founderShare = totalEarnings * 0.35;
    const developmentShare = totalEarnings * 0.15;
    
    const { error: founderError } = await supabase.rpc('update_founder_wallet', {
        founder_increment: founderShare,
        development_increment: developmentShare
    });
    if (founderError) console.error("Error updating founder wallet", founderError);

    return { success: true, amount: totalEarnings };
  };

  const checkIn = async () => {
    const now = new Date();
    const lastCheckIn = miningData.last_check_in ? new Date(miningData.last_check_in) : null;
    
    if (lastCheckIn && now.toDateString() === lastCheckIn.toDateString()) {
      return { success: false, message: 'You already checked in today!' };
    }

    const isConsecutive = lastCheckIn && (now.getTime() - lastCheckIn.getTime()) < 2 * 24 * 60 * 60 * 1000;
    const newStreak = isConsecutive ? miningData.check_in_streak + 1 : 1;
    const streakDay = Math.min(newStreak, 7);
    const rewards = [0.19, 0.29, 0.39, 0.49, 0.59, 0.69, 0.79];
    const reward = rewards[streakDay - 1];
    
    const { error } = await supabase
      .from('mining_data')
      .update({ check_in_streak: newStreak, last_check_in: now.toISOString() })
      .eq('user_id', user.id);
      
    if (error) throw error;
    setMiningData(prev => ({...prev, check_in_streak: newStreak, last_check_in: now.toISOString()}));
    
    await updateBalance('SPI', reward);
    await addTransaction({ type: 'checkin', amount: reward, coin: 'SPI', details: { streak: streakDay } });

    return { success: true, reward, streak: streakDay };
  };

  const value = {
    balances,
    miningData,
    transactions,
    founderWallet,
    isLoading,
    mine,
    checkIn,
    addTransaction,
    updateBalance,
    canTrade: () => user?.phase >= 3 && user?.kyc_status === 'verified',
    getBlockchainStats: () => ({ totalTransactions: 1, totalBlocks: 1, activeWallets: 1, networkHashrate: 'N/A', lastBlock: new Date().toISOString(), difficulty: 0 }),
    createWalletBackup: () => console.log("Backup feature to be implemented")
  };

  return (
    <WalletContext.Provider value={value}>
      {!isLoading && children}
    </WalletContext.Provider>
  );
};